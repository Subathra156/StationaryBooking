package com.TrafficMonitoringSys.ServletController;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

@Component


public class UserImpl extends  JdbcDaoSupport{

    @Autowired

    public UserImpl(DataSource dataSource)

    {

            setDataSource(dataSource);

    }

    public List<UserBean> select() {

            List<UserBean> userList = getJdbcTemplate().query("SELECT * FROM T_XBBNHD2_CIVIC_ADMIN",

            new Object[] {}, new TestRowMapper());

            return userList;

    }



}
