package com.TrafficMonitoringSys.ServletController;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/VC")
public class VolunteerController {
	String loc = "Pallavaram";

	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<VolunteerBean> get() {

		List<VolunteerBean> list = new ArrayList<VolunteerBean>();

		VolunteerDao vdao = new VolunteerDao();

		try {

			list = vdao.callAnotherTable();

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		return list;

	}

	@RequestMapping(value = "/all1", method = RequestMethod.DELETE)
	public String get1() throws SQLException {

		List<VolunteerBean> list = new ArrayList<VolunteerBean>();

		VolunteerDao vdao = new VolunteerDao();

		vdao.DeleteStatus(loc);
		return "1 row deleted";
	}

	@RequestMapping(value = "/all2", method = RequestMethod.GET)
	public List<CivicAuthorityBean> get2() {

		List<CivicAuthorityBean> list = new ArrayList<CivicAuthorityBean>();

		CivicAuthorityDao vdao = new CivicAuthorityDao();

		try {

			list = vdao.callAnotherTable();

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		return list;

	}

	@RequestMapping(value = "/all3", method = RequestMethod.GET, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<VolunteerBean> getDetails() {
		VolunteerDao dd = new VolunteerDao();
		List<VolunteerBean> li = dd.details1();
		return li;

	}

}
