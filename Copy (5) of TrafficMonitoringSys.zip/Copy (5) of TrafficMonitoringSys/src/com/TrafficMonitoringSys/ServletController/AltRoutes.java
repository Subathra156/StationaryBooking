package com.TrafficMonitoringSys.ServletController;

public class AltRoutes {
	String source,destination,possible_route,Duration,Distance;

	/**
	 * @return the source
	 */
	public String getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(String source) {
		this.source = source;
	}

	/**
	 * @return the destination
	 */
	public String getDestination() {
		return destination;
	}

	/**
	 * @param destination the destination to set
	 */
	public void setDestination(String destination) {
		this.destination = destination;
	}

	/**
	 * @return the possible_route
	 */
	public String getPossible_route() {
		return possible_route;
	}

	/**
	 * @param possible_route the possible_route to set
	 */
	public void setPossible_route(String possible_route) {
		this.possible_route = possible_route;
	}

	/**
	 * @return the duration
	 */
	public String getDuration() {
		return Duration;
	}

	/**
	 * @param duration the duration to set
	 */
	public void setDuration(String duration) {
		Duration = duration;
	}

	/**
	 * @return the distance
	 */
	public String getDistance() {
		return Distance;
	}

	/**
	 * @param distance the distance to set
	 */
	public void setDistance(String distance) {
		Distance = distance;
	}

}
