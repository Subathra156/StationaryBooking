package com.TrafficMonitoringSys.ServletController;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

	import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



	

	public class ServletController extends HttpServlet {
	                private static final long serialVersionUID = 1L;

	                public ServletController() {
	                                super();
	                                // TODO Auto-generated constructor stub
	                }

	                protected void doPost(HttpServletRequest request, HttpServletResponse response)
	                                                throws ServletException, IOException {
	                                PrintWriter out = response.getWriter();
	                                String userId = request.getParameter("uname");
	                                String passWord = request.getParameter("psw");
	                
	                                VolunteerDao volunteerdao=new VolunteerDao();
	                                
	                                
	                                try {
										if(volunteerdao.isCorrect(userId,passWord)) {
										                RequestDispatcher requestDispatcher = request.getRequestDispatcher("Option.html");
										                HttpSession session=request.getSession();  
										                session.setAttribute("uname",userId);  
										              /*  Cookie ck=new Cookie("LoginCookie",userId);
										                ck.setMaxAge(15);
										                response.addCookie(ck); */
										                requestDispatcher.forward(request, response);
										               // out.println("You have successfully logged out");
										               
														/*
										                * out.println("<script type=\"text/javascript\">"); out.println(
										                * "alert('Successful Login, Farmer!!!');");
										                * out.println("location='FarmerDashboard.jsp?user=" + userName +
										                * "';"); out.println("</script>");
										                */
										               
										                
										} else {
										                /*
										                * out.print("Sorry UserName or Password Error!"); RequestDispatcher
										                * requestDispatcher = request.getRequestDispatcher("/Login.jsp");
										                * requestDispatcher.include(request, response);
										                */
										                out.println("<script type=\"text/javascript\">");
										                out.println("alert('No such Account Found');");
										                out.println("location='Login1.html';");
										                out.println("</script>");
										}
									} catch (SQLException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
	                                // doPost(request, response);
	                }


	}
