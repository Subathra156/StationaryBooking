package com.TrafficMonitoringSys.ServletController;

public class VolunteerBean {
	private int v_id;
	private  String name,location1;
	private String status,time;
	
/**
	 * @return the time
	 */
	public String getTime() {
		return time;
	}
	/**
	 * @param time the time to set
	 */
	public void setTime(String time) {
		this.time = time;
	}
/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the v_id
	 */
	public int getV_id() {
		return v_id;
	}
	/**
	 * @param v_id the v_id to set
	 */
	public void setV_id(int v_id) {
		this.v_id = v_id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the location1
	 */
	public String getLocation1() {
		return location1;
	}
	/**
	 * @param location1 the location1 to set
	 */
	public void setLocation1(String location1) {
		this.location1 = location1;
	}

}
