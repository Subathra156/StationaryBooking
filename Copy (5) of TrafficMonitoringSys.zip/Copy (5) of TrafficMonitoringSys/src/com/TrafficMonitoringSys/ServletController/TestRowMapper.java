package com.TrafficMonitoringSys.ServletController;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;

public class TestRowMapper implements RowMapper<UserBean> {

    public UserBean mapRow(ResultSet rs, int rownum) throws SQLException {

            // TODO Auto-generated method stub      
            

    	UserBean user=new UserBean(); 

          

            user.setCivic_update(rs.getString(1));
            user.setLocation(rs.getString(2));
            user.setV_update(rs.getString(3));           

          
            

            return user;

    

    }
}

