package com.TrafficMonitoringSys.ServletController;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class UserDao {
	List<VolunteerBean> update3=null;
	List<CivicAuthorityBean> update1=null;
	public List<UserBean> Makeupdate(String location) {

		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<UserBean> update2=null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * FROM T_XBBNHD2_CIVIC_ADMIN where LOCATION=? ";
		try {
			stmt = conn.prepareStatement(searchQuery);
			stmt.setString(1, location);		

			resultset = stmt.executeQuery();	
			update2=new ArrayList<UserBean>();
			if(resultset!=null){
				//	map=new HashMap<String,String>();
				while(resultset.next())
				{    
					UserBean userBean=new UserBean();
					userBean.setLocation(resultset.getString("LOCATION"));
					userBean.setV_update(resultset.getString("V_UPDATE"));
					userBean.setCivic_update(resultset.getString("CIVIC_UPDATE"));
					//UserBean.setName(resultset.getString("V_NAME"));

					update2.add(userBean);


				}
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
					resultset.close();
				if(stmt != null)					
					stmt.close();				
				conn.commit();
				if(conn != null)
					conn.close();
			}			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return update2;
		//return getStatus(searchQuery);
	}

	public List callAnotherTable(String location) throws SQLException {
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt1 = null;
		String searchQuery = "SELECT * FROM T_XBBNHD2_VOLUNTEER where V_LOCATION=? ";
		ResultSet resultset1=null;
		try {
			stmt1 = conn.prepareStatement(searchQuery);
			stmt1.setString(1, location);		

			resultset1 = stmt1.executeQuery();	
			update3=new ArrayList<VolunteerBean>();
			while(resultset1.next())

			{    
				VolunteerBean volunteerbean=new VolunteerBean();
				volunteerbean.setV_id(resultset1.getInt("V_ID"));
				volunteerbean.setLocation1(resultset1.getString("V_LOCATION"));
				volunteerbean.setStatus(resultset1.getString("V_STATUS"));
				volunteerbean.setName(resultset1.getString("V_NAME"));

				update3.add(volunteerbean);

				
			}



		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset1 != null)
					resultset1.close();
				if(stmt1 != null)					
					stmt1.close();				
				conn.commit();
				if(conn != null)
					conn.close();
			}			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return update3;	
	} 

	public List callSecondTable(String location) throws SQLException {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt1 = null;
		String searchQuery = "SELECT * FROM T_XBBNHD2_CIVIC_AUTHORITY where C_LOCATION=? ";
		ResultSet resultset1=null;
		try {
			stmt1 = conn.prepareStatement(searchQuery);
			stmt1.setString(1, location);		

			resultset1 = stmt1.executeQuery();	
			update1=new ArrayList<CivicAuthorityBean>();
			while(resultset1.next())

			{    
				CivicAuthorityBean cbean=new CivicAuthorityBean();
				cbean.setLocation1(resultset1.getString("C_LOCATION"));

				cbean.setUpdate(resultset1.getString("C_UPDATE"));


				update1.add(cbean);


			}



		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset1 != null)
					resultset1.close();
				if(stmt1 != null)					
					stmt1.close();				
				conn.commit();
				if(conn != null)
					conn.close();
			}			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return update1;	
	}

	public List<UserBean> details1() {
		// TODO Auto-generated method stub
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<UserBean> update2=null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * FROM T_XBBNHD2_CIVIC_ADMIN";
		try {
			stmt = conn.prepareStatement(searchQuery);
				

			resultset = stmt.executeQuery();	
			update2=new ArrayList<UserBean>();
			if(resultset!=null){
				//	map=new HashMap<String,String>();
				while(resultset.next())
				{    
					UserBean userBean=new UserBean();
					userBean.setLocation(resultset.getString("LOCATION"));
					userBean.setV_update(resultset.getString("V_UPDATE"));
					userBean.setCivic_update(resultset.getString("CIVIC_UPDATE"));
					//UserBean.setName(resultset.getString("V_NAME"));

					update2.add(userBean);


				}
			}


		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
					resultset.close();
				if(stmt != null)					
					stmt.close();				
				conn.commit();
				if(conn != null)
					conn.close();
			}			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return update2;
	} 

}
