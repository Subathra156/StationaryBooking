package com.TrafficMonitoringSys.ServletController;

import java.sql.*;
public class ConnectionManager {
       static Connection con;
          static String url;
                
          public static Connection getConnection()
          {
            
             try
             {
               // String url = "jdbc:odbc:" + "DataSource"; 
                // assuming "DataSource" is your DataSource name
            	 //Class.forName("oracle.jdbc.driver.OracleDriver");
             Class.forName("org.apache.derby.jdbc.ClientDriver");
              //jdbc:derby://172.24.18.39:1527/weatherdb","user","pwd
               //org.apache.derby.jdbc.ClientDriver 
              
                   try {
                                  con = DriverManager.getConnection("jdbc:derby://172.24.21.45:1527/Tmsdb","user","pwd");
                	 //  con = DriverManager.getConnection("jdbc:derby://172.24.19.159:1527/Tmsdb","user","pwd");
                	   //con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

                   } catch (SQLException e) {
                                  // TODO Auto-generated catch block
                                  e.printStackTrace();
                           }
                                                                     
                // assuming your SQL Server's   username is "username"               
                // and password is "password"
                   //jdbc:derby://172.24.21.45:1527/Tmsdb;create=true 
                
                
             }

             catch(ClassNotFoundException e)
             {
                System.out.println(e);
                System.out.println("hey");
             }

          return con;
       }
}





