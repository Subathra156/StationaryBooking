package com.TrafficMonitoringSys.ServletController;

import java.io.IOException;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class VolunteerUpdateServlet extends HttpServlet {
	  protected void doGet(HttpServletRequest request, HttpServletResponse response)
              throws ServletException, IOException {
		  int id=Integer.parseInt(request.getParameter("id"));
		  String location=request.getParameter("loc");
		  String update=request.getParameter("update");
		  String name=request.getParameter("name");
		  String d=request.getParameter("dt");
		  System.out.println(d);
		  VolunteerDao volunteerdao=new VolunteerDao();
		  volunteerdao.Makeupdate(id,location,name,update,d);
		  RequestDispatcher requestDispatcher = request.getRequestDispatcher("Page2.html");
			requestDispatcher.forward(request, response);
}
}
