package com.TrafficMonitoringSys.ServletController;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;

import org.apache.log4j.Logger;

public class VolunteerDao {
	final static Logger logger = Logger.getLogger(VolunteerDao.class);
	public List<VolunteerBean> Makeupdate(int id,String name,String location,String status,String d) {
		Connection conn = ConnectionManager.getConnection();
	
		PreparedStatement stmt = null;
		//Map map = null;
		List<VolunteerBean> status1=null;
		ResultSet resultset = null;
		
		String searchQuery = "INSERT INTO T_XBBNHD2_VOLUNTEER " +
                "VALUES (?, ?, ?, ?,?)";
		try {
			 stmt = conn.prepareStatement(searchQuery);
	// stmt.setString(1, location);		
			 stmt.setInt(1,id);
			 stmt.setString(2,location);
			 stmt.setString(3,name);
			 stmt.setString(4,status);
			 stmt.setString(5, d);
		
			 stmt.executeUpdate();	
			 status1=new ArrayList<VolunteerBean>();
			
		//	map=new HashMap<String,String>();
		/*	while(resultset.next())
 			{    
				VolunteerBean volunteerbean=new VolunteerBean();
				volunteerbean.setV_id(resultset.getInt("V_ID"));
				volunteerbean.setLocation1(resultset.getString("V_LOCATION"));
				volunteerbean.setStatus(resultset.getString("V_STATUS"));
				volunteerbean.setName(resultset.getString("V_NAME"));
				
				status1.add(volunteerbean);
				
						
			}*/
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Location already exists!");
			
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return status1;
		//return getStatus(searchQuery);
		
	}
	public boolean isAvailable(String userId) throws SQLException
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        
        stmt = con.prepareStatement("select * from T_XBBNHD2_CREDENTIALS where USER_NAME = ?");
        stmt.setString(1, userId);
        boolean isCorrect = false;
        ResultSet rs = null;
        
        rs = stmt.executeQuery();
               
        while(rs.next())
        {
               isCorrect = true;
        }
        con.close();
        return isCorrect;
	}

	
	public boolean isLocAvailable(String userId) throws SQLException
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        
        stmt = con.prepareStatement("select * from T_XBBNHD2_CREDENTIALS where LOCATION = ?");
        stmt.setString(1, userId);
        boolean isCorrect = false;
        ResultSet rs = null;
        
        rs = stmt.executeQuery();
               
        while(rs.next())
        {
               isCorrect = true;
        }
        con.close();
        return isCorrect;
	}

	public boolean isCorrect(String userId, String passWord) throws SQLException {
		
		// TODO Auto-generated method stub
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        
        stmt = con.prepareStatement("select * from T_XBBNHD2_CREDENTIALS where USER_NAME = ? AND PASSWORD= ?");
        stmt.setString(1, userId);
        stmt.setString(2, passWord);
 
 boolean isCorrect = false;
 ResultSet rs = null;
 
 rs = stmt.executeQuery();
        
 while(rs.next())
 {
        isCorrect = true;
 }
 con.close();
 return isCorrect;
		}
	public void UpdateStatus(String update,String location)
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        try{
        stmt = con.prepareStatement("update T_XBBNHD2_VOLUNTEER set V_STATUS=? WHERE V_LOCATION=? ");
        stmt.setString(1,update);
        stmt.setString(2,location);
        stmt.executeUpdate();}
        catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
        
		
        
	}
	public void DeleteStatus(String location)
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        try{
        stmt = con.prepareStatement("delete from T_XBBNHD2_VOLUNTEER WHERE V_LOCATION=? ");
        
        stmt.setString(1,location);
        stmt.executeUpdate();
        }
        catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
        public List callAnotherTable() throws SQLException 
        {
    		// TODO Auto-generated method stub
    		Connection conn = ConnectionManager.getConnection();
    		PreparedStatement stmt1 = null;
    		String searchQuery = "SELECT * FROM T_XBBNHD2_VOLUNTEER ";
    		List<VolunteerBean> update3=null;
    		ResultSet resultset1=null;
    		try {
    			stmt1 = conn.prepareStatement(searchQuery);
    		//	stmt1.setString(1, loc);		

    			resultset1 = stmt1.executeQuery();	
    			update3=new ArrayList<VolunteerBean>();
    			while(resultset1.next())

    			{    
    				VolunteerBean volunteerbean=new VolunteerBean();
    				volunteerbean.setV_id(resultset1.getInt("V_ID"));
    				volunteerbean.setLocation1(resultset1.getString("V_LOCATION"));
    				volunteerbean.setStatus(resultset1.getString("V_STATUS"));
    				volunteerbean.setName(resultset1.getString("V_NAME"));
    				volunteerbean.setTime(resultset1.getString("DATE_TIME"));
    				

    				update3.add(volunteerbean);

    				
    			}



    		}
    		catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    		finally{
    			try {
    				if(resultset1 != null)
    					resultset1.close();
    				if(stmt1 != null)					
    					stmt1.close();				
    				conn.commit();
    				if(conn != null)
    					conn.close();
    			}			
    			catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		}
    		return update3;	
    	}
		public List<VolunteerBean> details1() {
			// TODO Auto-generated method stub
			Connection conn = ConnectionManager.getConnection();
    		PreparedStatement stmt1 = null;
    		String searchQuery = "SELECT * FROM T_XBBNHD2_VOLUNTEER ";
    		List<VolunteerBean> update3=null;
    		ResultSet resultset1=null;
    		try {
    			stmt1 = conn.prepareStatement(searchQuery);
    		//	stmt1.setString(1, loc);		

    			resultset1 = stmt1.executeQuery();	
    			update3=new ArrayList<VolunteerBean>();
    			while(resultset1.next())

    			{    
    				VolunteerBean volunteerbean=new VolunteerBean();
    				volunteerbean.setV_id(resultset1.getInt("V_ID"));
    				volunteerbean.setLocation1(resultset1.getString("V_LOCATION"));
    				volunteerbean.setStatus(resultset1.getString("V_STATUS"));
    				volunteerbean.setName(resultset1.getString("V_NAME"));
    				volunteerbean.setTime(resultset1.getString("DATE_TIME"));
    				

    				update3.add(volunteerbean);

    				
    			}



    		}
    		catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    		finally{
    			try {
    				if(resultset1 != null)
    					resultset1.close();
    				if(stmt1 != null)					
    					stmt1.close();				
    				conn.commit();
    				if(conn != null)
    					conn.close();
    			}			
    			catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		}
    		return update3;	
    	}
        
	
}



