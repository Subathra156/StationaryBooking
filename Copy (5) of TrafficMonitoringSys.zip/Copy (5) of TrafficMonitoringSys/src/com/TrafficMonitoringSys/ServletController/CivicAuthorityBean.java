package com.TrafficMonitoringSys.ServletController;

public class CivicAuthorityBean {

	private  String name,location1,designation;
	private String update;
	/**
	 * @return the status
	 */
	public String getUpdate() {
		return update;
	}
	/**
	 * @param status the status to set
	 */
	public void setUpdate(String update) {
		this.update = update;
	}
	/**
	 * @return the v_id
	 */
	public String getDesignation() {
		return designation;
	}
	/**
	 * @param v_id the v_id to set
	 */
	public void  setDesignation(String designation ) {
		this.designation = designation;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the location1
	 */
	public String getLocation1() {
		return location1;
	}
	/**
	 * @param location1 the location1 to set
	 */
	public void setLocation1(String location1) {
		this.location1 = location1;
	}

}
