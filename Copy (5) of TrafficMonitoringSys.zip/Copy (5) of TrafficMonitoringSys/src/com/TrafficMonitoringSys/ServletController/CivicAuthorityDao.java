package com.TrafficMonitoringSys.ServletController;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CivicAuthorityDao {

	public List<CivicAuthorityBean> Makeupdate(String name,String designation,String location,String update) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<CivicAuthorityBean> update1=null;
		ResultSet resultset = null;
		String Query = "INSERT INTO T_XBBNHD2_CIVIC_AUTHORITY " +
                "VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(Query);
	 stmt.setString(1,name);
	 stmt.setString(2,designation);
	 stmt.setString(3,location);
	 stmt.setString(4,update);
	 
		
			  stmt.executeUpdate();	
			 update1=new ArrayList<CivicAuthorityBean>();
			
		//	map=new HashMap<String,String>();
		/*	while(resultset.next())
 			{    
				CivicAuthorityBean cvbean=new CivicAuthorityBean();
				cvbean.setUpdate(resultset.getString("C_UPDATE"));
				cvbean.setName(resultset.getString("C_NAME"));
				cvbean.setLocation1(resultset.getString("C_LOCATION"));
				cvbean.setDesignation(resultset.getString("C_DESIGNATION"));
				
				
				update1.add(cvbean);
				
						
			}
			*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return update1;
		//return getStatus(searchQuery);
	}
	public void UpdateStatus(String update,String location)
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        try{
        stmt = con.prepareStatement("update T_XBBNHD2_CIVIC_AUTHORITY set C_UPDATE=? WHERE C_LOCATION=? ");
        stmt.setString(1,update);
        stmt.setString(2,location);
        stmt.executeUpdate();}
        catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	

}
	
	public void DeleteStatus(String location)
	{
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        try{
        stmt = con.prepareStatement("delete from T_XBBNHD2_VOLUNTEER WHERE V_LOCATION=? ");
        
        stmt.setString(1,location);
        stmt.executeUpdate();
        }
        catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
        public List callAnotherTable() throws SQLException 
        {
    		// TODO Auto-generated method stub
    		Connection conn = ConnectionManager.getConnection();
    		PreparedStatement stmt1 = null;
    		ResultSet resultset1=null;
    		String searchQuery = "SELECT * FROM T_XBBNHD2_CIVIC_AUTHORITY ";
    		List<CivicAuthorityBean> update3=null;
    		
    		try {
    			stmt1 = conn.prepareStatement(searchQuery);
    		//	stmt1.setString(1, loc);		

    			resultset1 = stmt1.executeQuery();	
    			update3=new ArrayList<CivicAuthorityBean>();
    			while(resultset1.next())

    			{    
    				CivicAuthorityBean volunteerbean=new CivicAuthorityBean();
    				volunteerbean.setName(resultset1.getString("C_NAME"));
    				volunteerbean.setLocation1(resultset1.getString("C_LOCATION"));
    				volunteerbean.setDesignation(resultset1.getString("C_DESIGNATION"));
    				volunteerbean.setUpdate(resultset1.getString("C_UPDATE"));

    				update3.add(volunteerbean);

    				
    			}



    		}
    		catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}	
    		finally{
    			try {
    				if(resultset1 != null)
    					resultset1.close();
    				if(stmt1 != null)					
    					stmt1.close();				
    				conn.commit();
    				if(conn != null)
    					conn.close();
    			}			
    			catch (SQLException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    			}
    		}
    		return update3;	
    	} 
        
	
}

		// TODO Auto-generated method stub
		
	



