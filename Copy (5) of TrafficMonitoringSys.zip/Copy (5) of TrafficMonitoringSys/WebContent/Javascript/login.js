
function Redirect()
{
	

	if(document.getElementById("r1").checked)
	window.location="Page2.html";
	else{
		window.location="Page3.html";
			}
}