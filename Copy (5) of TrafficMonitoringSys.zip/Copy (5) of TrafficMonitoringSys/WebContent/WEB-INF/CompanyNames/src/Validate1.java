import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpRetryException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Validate1 extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		String uname=request.getParameter("uname");
		Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(uname);
		boolean b = m.find();

		if(b)
		{
			out.println("Special characters are not allowed in the user name");
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("index.jsp");
			requestDispatcher.include(request, response);
		}
	
		/* try{
		if (uname.contains(" ")) {

throw new SpaceFoundException("Exception occured");
			
		}
		}
		catch(Exception e){} */
		if(!b)
		{
			HttpSession session=request.getSession();  
	        session.setAttribute("uname",uname);  
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("StockController");
			requestDispatcher.forward(request, response);
		}
			
		   
	}

}
