
public class SpaceFoundException  extends Exception{  
	SpaceFoundException(String s){  
		  super(s);  
		 }  
		}  


