package User;

public class UserBean {
	
	
	private String modeOfTransport;
	private String Location,v_update,civic_update;
	
	/**
	 * @return the location
	 */
	public String getLocation() {
		return Location;
	}

	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		Location = location;
	}

	/**
	 * @return the v_update
	 */
	public String getV_update() {
		return v_update;
	}

	/**
	 * @param v_update the v_update to set
	 */
	public void setV_update(String v_update) {
		this.v_update = v_update;
	}

	/**
	 * @return the civic_update
	 */
	public String getCivic_update() {
		return civic_update;
	}

	/**
	 * @param civic_update the civic_update to set
	 */
	public void setCivic_update(String civic_update) {
		this.civic_update = civic_update;
	}

	public String getModeOfTransport() {
		return modeOfTransport;
	}
	
	public void setModeOfTransport(String modeOfTransport) {
		this.modeOfTransport = modeOfTransport;
	}
	
	

}
