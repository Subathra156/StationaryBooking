package User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import CivicAuthority.CivicAuthorityBean;
import ConnectionManager.ConnectionManager;
import Volunteer.VolunteerBean;

public class UserDao {
	List<VolunteerBean> status1=null;
	List<CivicAuthorityBean> update1=null;
	public List<UserBean> Makeupdate(String location) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<UserBean> update2=null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * FROM T_XBBNHD2_CIVIC_ADMIN where LOCATION=? ";
		try {
			 stmt = conn.prepareStatement(searchQuery);
	stmt.setString(1, location);		
		
			 resultset = stmt.executeQuery();	
			 update2=new ArrayList<UserBean>();
			
		//	map=new HashMap<String,String>();
			while(resultset.next())
 			{    
				UserBean userBean=new UserBean();
				userBean.setLocation(resultset.getString("LOCATION"));
				userBean.setV_update(resultset.getString("V_UPDATE"));
				userBean.setCivic_update(resultset.getString("CIVIC_UPDATE"));
				//UserBean.setName(resultset.getString("V_NAME"));
				
				update2.add(userBean);
				
						
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return update2;
		//return getStatus(searchQuery);
	}

	
	}



