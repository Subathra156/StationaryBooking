package User;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class UserApp {
	public static void main(String[] args) {
		/* Map<String,String> map=new HashMap<String,String>();
		String Source="Taramani";
		String dest="Pallavaram";
	String Status="congested";
				String s=Source+","+dest;
		// TODO Auto-generated method stub
String Location;
TrafficDao trafficdao=new TrafficDao();
String status=trafficdao.getStatus(s);
map.put(s,status);
System.out.println(map); */
		Scanner in= new Scanner(System.in);
		System.out.println("Enter your location");
		
		String location=in.nextLine();
	//	
	//trafficbean.setLocation("Pallavaram");
		UserDao userdao=new UserDao();
	
	//	String status=trafficdao.getStatus(trafficbean.getLocation());
		//Map<String,String> map=new HashMap<String,String>();

		//if(map.containsKey(trafficbean.getLocation()))
		//{
		//	System.out.println(status);
			
		//}
	//	String location="";
		List<UserBean> update2=userdao.Makeupdate(location);
		Iterator<UserBean> itr= update2.iterator();
		while(itr.hasNext())
		{
			UserBean userbean=itr.next();
		System.out.println(userbean.getLocation() + " "+ userbean.getV_update() + " " +userbean.getCivic_update());
			
		}

	}
}


