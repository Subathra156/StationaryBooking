package com.inautix.sample.traffic;

public class AdminBean {
private String location,V_Update,Civic_Update;

/**
 * @return the location
 */
public String getLocation() {
	return location;
}

/**
 * @param location the location to set
 */
public void setLocation(String location) {
	this.location = location;
}

/**
 * @return the v_Update
 */
public String getV_Update() {
	return V_Update;
}

/**
 * @param v_Update the v_Update to set
 */
public void setV_Update(String v_Update) {
	V_Update = v_Update;
}

/**
 * @return the civic_Update
 */
public String getCivic_Update() {
	return Civic_Update;
}

/**
 * @param civic_Update the civic_Update to set
 */
public void setCivic_Update(String civic_Update) {
	Civic_Update = civic_Update;
} 
}
