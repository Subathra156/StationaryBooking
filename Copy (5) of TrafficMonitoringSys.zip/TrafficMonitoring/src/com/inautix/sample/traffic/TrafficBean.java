package com.inautix.sample.traffic;

public class TrafficBean {
	private String location;
	private String v_update,civic_update;
	/**
	 * @return the location
	 */
	public String getLocation() {
		return location;
	}
	/**
	 * @param location the location to set
	 */
	public void setLocation(String location) {
		this.location = location;
	}
	/**
	 * @return the v_update
	 */
	public String getV_update() {
		return v_update;
	}
	/**
	 * @param v_update the v_update to set
	 */
	public void setV_update(String v_update) {
		this.v_update = v_update;
	}
	/**
	 * @return the civic_update
	 */
	public String getCivic_update() {
		return civic_update;
	}
	/**
	 * @param civic_update the civic_update to set
	 */
	public void setCivic_update(String civic_update) {
		this.civic_update = civic_update;
	}

	

}
