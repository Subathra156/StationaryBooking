package com.inautix.sample.traffic;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CivicAuthorityApp {
	
		public static void main(String[] args) {
			Scanner in= new Scanner(System.in);
			System.out.println("Enter name");
			String Name=in.nextLine();
			System.out.println("Enter designation");
			String Designation=in.nextLine();
			try{
			System.out.println("Enter location");
			}catch(Exception e){}
			String location=in.nextLine();
			System.out.println("Enter update");
			String update=in.nextLine();
			
			/* Map<String,String> map=new HashMap<String,String>();
			String Source="Taramani";
			String dest="Pallavaram";
		String Status="congested";
					String s=Source+","+dest;
			// TODO Auto-generated method stub
	String Location;
	TrafficDao trafficdao=new TrafficDao();
	String status=trafficdao.getStatus(s);
	map.put(s,status);
	System.out.println(map); */
		//	String location="Pallavaram";
		//	
		//trafficbean.setLocation("Pallavaram");
			CivicAuthorityDao cvdao=new CivicAuthorityDao();
		
		//	String status=trafficdao.getStatus(trafficbean.getLocation());
			//Map<String,String> map=new HashMap<String,String>();

			//if(map.containsKey(trafficbean.getLocation()))
			//{
			//	System.out.println(status);
				
			//}
		//	String location="";
			List<CivicAuthorityBean> update1=cvdao.Makeupdate(Name,Designation,location,update);
	/*		Iterator<CivicAuthorityBean> itr= update1.iterator();
			while(itr.hasNext())
			{
				CivicAuthorityBean cvbean=itr.next();
			System.out.println(cvbean.getDesignation()+ " " +cvbean.getLocation1() + " "+ cvbean.getName() + " " +cvbean.getUpdate());
				
			} */

		}
	}


