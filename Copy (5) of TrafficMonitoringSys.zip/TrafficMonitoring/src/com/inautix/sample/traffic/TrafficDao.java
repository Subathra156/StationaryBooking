package com.inautix.sample.traffic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
//import java.util.HashMap;
//import java.util.Map;

public class TrafficDao {

	public List<TrafficBean> getupdate(String location) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<TrafficBean> status1=null;
		ResultSet resultset = null;
		String searchQuery = "SELECT * from T_XBBNHD2_CIVIC_ADMIN";
		try {
			 stmt = conn.prepareStatement(searchQuery);
	// stmt.setString(1, location);		
		
			 resultset = stmt.executeQuery();	
			 status1=new ArrayList<TrafficBean>();
			
		//	map=new HashMap<String,String>();
			while(resultset.next())
 			{    
				TrafficBean trafficbean=new TrafficBean();
				trafficbean.setLocation(resultset.getString("LOCATION"));
				trafficbean.setCivic_update(resultset.getString("V_UPDATE"));
				trafficbean.setV_update(resultset.getString("CIVIC_UPDATE"));
				status1.add(trafficbean);
				
						
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return status1;
		//return getStatus(searchQuery);
	}
	

}
