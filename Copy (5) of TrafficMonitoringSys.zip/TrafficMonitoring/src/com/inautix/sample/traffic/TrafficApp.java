package com.inautix.sample.traffic;

import java.util.Iterator;
import java.util.List;

public class TrafficApp {

	public static void main(String[] args) {
		/* Map<String,String> map=new HashMap<String,String>();
		String Source="Taramani";
		String dest="Pallavaram";
	String Status="congested";
				String s=Source+","+dest;
		// TODO Auto-generated method stub
String Location;
TrafficDao trafficdao=new TrafficDao();
String status=trafficdao.getStatus(s);
map.put(s,status);
System.out.println(map); */
		String location="pallavaram";
	//	
	//trafficbean.setLocation("Pallavaram");
		TrafficDao trafficdao=new TrafficDao();
	
	//	String status=trafficdao.getStatus(trafficbean.getLocation());
		//Map<String,String> map=new HashMap<String,String>();

		//if(map.containsKey(trafficbean.getLocation()))
		//{
		//	System.out.println(status);
			
		//}
	//	String location="";
		List<TrafficBean> status1=trafficdao.getupdate(location);
		Iterator<TrafficBean> itr= status1.iterator();
		while(itr.hasNext())
		{
			TrafficBean trafficbean=itr.next();
		System.out.println(trafficbean.getLocation()+ " " +trafficbean.getCivic_update() + " " + trafficbean.getV_update() );
		System.out.println();
			
		}
		
		
		
		

	}

}
