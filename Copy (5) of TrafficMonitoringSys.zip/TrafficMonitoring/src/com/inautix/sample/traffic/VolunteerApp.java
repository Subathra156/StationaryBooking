package com.inautix.sample.traffic;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class VolunteerApp {
	public static void main(String args[])
	{
	Scanner in= new Scanner(System.in);
	System.out.println("Enter volunteer id");
	int id=in.nextInt();
	 in.nextLine();
	 System.out.println("Enter volunteer name");
	 String Name=in.nextLine();
	 try{
	System.out.println("Enter location");
	 }catch(Exception e){}
	String location=in.nextLine();
	System.out.println("Enter status");
	String status=in.nextLine();
	
	
	/* Map<String,String> map=new HashMap<String,String>();
	String Source="Taramani";
	String dest="Pallavaram";
String Status="congested";
			String s=Source+","+dest;
	// TODO Auto-generated method stub
String Location;
TrafficDao trafficdao=new TrafficDao();
String status=trafficdao.getStatus(s);
map.put(s,status);
System.out.println(map); */
//	String location="Pallavaram";
//	
//trafficbean.setLocation("Pallavaram");
	VolunteerDao vdao=new VolunteerDao();

//	String status=trafficdao.getStatus(trafficbean.getLocation());
	//Map<String,String> map=new HashMap<String,String>();

	//if(map.containsKey(trafficbean.getLocation()))
	//{
	//	System.out.println(status);
		
	//}
//	String location="";
	List<VolunteerBean> update1=vdao.Makeupdate(id,location,Name,status);
/*		Iterator<CivicAuthorityBean> itr= update1.iterator();
	while(itr.hasNext())
	{
		CivicAuthorityBean cvbean=itr.next();
	System.out.println(cvbean.getDesignation()+ " " +cvbean.getLocation1() + " "+ cvbean.getName() + " " +cvbean.getUpdate());
		
	} */

	}
}
