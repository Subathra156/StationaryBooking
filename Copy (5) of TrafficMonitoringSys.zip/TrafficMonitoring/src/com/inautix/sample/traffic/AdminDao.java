package com.inautix.sample.traffic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AdminDao {
	

		public void makeupdate() {
			Connection conn = ConnectionManager.getConnection();
			PreparedStatement stmt = null;
			PreparedStatement stmt1=null;
			//Map map = null;
			List<AdminBean> status1=null;
			ResultSet resultset = null;
		String searchQuery1 ="INSERT INTO T_XBBNHD2_CIVIC_ADMIN (LOCATION,V_UPDATE,CIVIC_UPDATE) SELECT T_XBBNHD2_VOLUNTEER.V_LOCATION,V_STATUS,C_UPDATE FROM T_XBBNHD2_VOLUNTEER JOIN T_XBBNHD2_CIVIC_AUTHORITY ON T_XBBNHD2_VOLUNTEER.V_LOCATION=T_XBBNHD2_CIVIC_AUTHORITY.C_LOCATION";
		//	String searchQuery2 = "INSERT INTO T_XBBNHD2_CIVIC_ADMIN (CIVIC_UPDATE,LOCATION) SELECT C_UPDATE,C_LOCATION FROM T_XBBNHD2_CIVIC_AUTHORITY";
			try {
				 stmt = conn.prepareStatement(searchQuery1);
				// stmt1 = conn.prepareStatement(searchQuery2);
		// stmt.setString(1, location);		
			
				 stmt.executeUpdate();	
				// stmt1.executeUpdate();
				/* status1=new ArrayList<AdminBean>();
				
			//	map=new HashMap<String,String>();
				while(resultset.next())
	 			{    
					TrafficBean trafficbean=new TrafficBean();
					trafficbean.setStatus(resultset.getString("STATUS"));
					status1.add(trafficbean);
					
							
				} */
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			finally{
				try {
					if(resultset != null)
					resultset.close();
					if(stmt != null)					
					stmt.close();				
					conn.commit();
					if(conn != null)
					conn.close();
				}			
				 catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			}
			//return status1;
			//return getStatus(searchQuery);
		}
		


}
