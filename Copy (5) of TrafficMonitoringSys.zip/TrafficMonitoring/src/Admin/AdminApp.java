package Admin;

import java.util.List;

public class AdminApp {
	public static void main(String args[])
	{
	AdminDao admindao=new AdminDao();
	admindao.makeupdate();
	
	//	String status=trafficdao.getStatus(trafficbean.getLocation());
		//Map<String,String> map=new HashMap<String,String>();

		//if(map.containsKey(trafficbean.getLocation()))
		//{
		//	System.out.println(status);
			
		//}
	//	String location="";
	

}
}
