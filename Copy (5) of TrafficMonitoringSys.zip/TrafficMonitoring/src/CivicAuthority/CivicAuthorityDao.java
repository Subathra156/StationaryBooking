package CivicAuthority;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ConnectionManager.ConnectionManager;

public class CivicAuthorityDao {

	public List<CivicAuthorityBean> Makeupdate(String name,String designation,String location,String update) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<CivicAuthorityBean> update1=null;
		ResultSet resultset = null;
		String Query = "INSERT INTO T_XBBNHD2_CIVIC_AUTHORITY " +
                "VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(Query);
	 stmt.setString(1,name);
	 stmt.setString(2,designation);
	 stmt.setString(3,location);
	 stmt.setString(4,update);
	 
		
			  stmt.executeUpdate();	
			 update1=new ArrayList<CivicAuthorityBean>();
			
		//	map=new HashMap<String,String>();
		/*	while(resultset.next())
 			{    
				CivicAuthorityBean cvbean=new CivicAuthorityBean();
				cvbean.setUpdate(resultset.getString("C_UPDATE"));
				cvbean.setName(resultset.getString("C_NAME"));
				cvbean.setLocation1(resultset.getString("C_LOCATION"));
				cvbean.setDesignation(resultset.getString("C_DESIGNATION"));
				
				
				update1.add(cvbean);
				
						
			}
			*/
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return update1;
		//return getStatus(searchQuery);
	}
	

}

		// TODO Auto-generated method stub
		
	



