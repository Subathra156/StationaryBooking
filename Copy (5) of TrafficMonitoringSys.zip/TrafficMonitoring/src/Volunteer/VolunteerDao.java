package Volunteer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ConnectionManager.ConnectionManager;

public class VolunteerDao {
	public List<VolunteerBean> Makeupdate(int id,String location,String name,String status) {
		Connection conn = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		//Map map = null;
		List<VolunteerBean> status1=null;
		ResultSet resultset = null;
		String searchQuery = "INSERT INTO T_XBBNHD2_VOLUNTEER VALUES (?, ?, ?, ?)";
		try {
			 stmt = conn.prepareStatement(searchQuery);
	// stmt.setString(1, location);		
			 stmt.setInt(1,id);
			 stmt.setString(2,location);
			 stmt.setString(3,name);
			 stmt.setString(4,status);
		
			 stmt.executeUpdate();	
			 status1=new ArrayList<VolunteerBean>();
			
		//	map=new HashMap<String,String>();
		/*	while(resultset.next())
 			{    
				VolunteerBean volunteerbean=new VolunteerBean();
				volunteerbean.setV_id(resultset.getInt("V_ID"));
				volunteerbean.setLocation1(resultset.getString("V_LOCATION"));
				volunteerbean.setStatus(resultset.getString("V_STATUS"));
				volunteerbean.setName(resultset.getString("V_NAME"));
				
				status1.add(volunteerbean);
				
						
			}*/
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		finally{
			try {
				if(resultset != null)
				resultset.close();
				if(stmt != null)					
				stmt.close();				
				conn.commit();
				if(conn != null)
				conn.close();
			}			
			 catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		return status1;
		//return getStatus(searchQuery);
	}

	public boolean isCorrect(String userId, String passWord) throws SQLException {
		
		// TODO Auto-generated method stub
		Connection con = ConnectionManager.getConnection();
        PreparedStatement stmt = null;
        
        stmt = con.prepareStatement("select * from T_XBBNHD2_CREDENTIALS where USER_NAME = ? AND PASSWORD= ?");
        stmt.setString(1, userId);
        stmt.setString(2, passWord);
 
 boolean isCorrect = false;
 ResultSet rs = null;
 
 rs = stmt.executeQuery();
        
 while(rs.next())
 {
        isCorrect = true;
 }
 con.close();
 return isCorrect;
		
	}
}

