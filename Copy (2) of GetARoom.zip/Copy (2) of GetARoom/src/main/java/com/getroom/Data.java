package com.getroom;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;




public class Data {
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<RoomBean> output;
	
	
	public List<RoomBean>  getOutput() {
		return output;
	}
	public void setOutput(List<RoomBean> outputList) {
		this.output = outputList;
	}

}
