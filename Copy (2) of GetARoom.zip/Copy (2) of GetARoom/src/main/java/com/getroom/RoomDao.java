package com.getroom;

import java.util.List;

public interface RoomDao {

	public List<RoomBean> getRooms(String aim_no);
	public List<RoomBean> getRooms();
	public void insert(RoomBean rb);
}
