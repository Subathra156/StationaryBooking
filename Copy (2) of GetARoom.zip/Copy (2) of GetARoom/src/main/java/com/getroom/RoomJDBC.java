package com.getroom;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;


public class RoomJDBC implements RoomDao {
	
	private DataSource dataSource;
	   private JdbcTemplate jdbcTemplateObject;
	   List<RoomBean> rb=new ArrayList<RoomBean>();   
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }


	public List<RoomBean> getRooms(String aim_no) {
		String SQL = "select * from XBBNHD2ROOMS where AIM_NO=?";
	    rb = jdbcTemplateObject.query(SQL, new Object[]{aim_no}, new RoomMapper());
		return rb;
	}
	
	public List<RoomBean> getRooms() {
		String SQL = "select * from XBBNHD2ROOMS";
	    rb = jdbcTemplateObject.query(SQL, new Object[]{}, new RoomMapper());
		return rb;
	}


	public void insert(RoomBean rb1) {
		/*// TODO Auto-generated method stub
		String SQL = "insert into XBBNHD2ROOMS values(" + rb.getEmp_id() + ",'"
				+ rb.getAim_no() + "','" + rb.getRooms() + "','" + rb.getCapacity() + "')";
		jdbcTemplateObject.update(SQL);
		
		String SQL = "insert into cust values(" + c.getId() + ",'"
				+ c.getName() + "','" + c.getItem() + "')";
*/
		
		
		

	        // TODO Auto-generated method stub

			int numRows = 0;
			Date date = new Date();
			
			int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
					Types.INTEGER };
			Object param[] = {rb1.getEmpId(),rb1.getAimNo(), rb1.getRooms() ,rb1.getCapacity()};
			
			numRows= jdbcTemplateObject.update("insert into XBBNHD2ROOMS values(?,?,?,?)",param,types);
			

		}


	public RoomBean deleteRooms(String rooms) {
		
			// TODO Auto-generated method stub
			int numRows = 0;
			RoomBean rb = null;
			try {
				rb= jdbcTemplateObject.queryForObject(
						"select * from XBBNHD2ROOMS ROOMS = ? ",
						new Object[] { rooms }, new RoomMapper());
				numRows = jdbcTemplateObject.update(
						"delete from XBBNHD2ROOMS ROOMS=?",
						new Object[] { rooms }, new int[] { Types.VARCHAR });

			} catch (Throwable error) {
				System.out.println("Got error.  Returning null (404)");
				error.printStackTrace();
			}
			return(numRows == 1 ? rb : null);
			

		}


	public RoomBean updateRooms(RoomBean rooms) {
        int numRows = 0;
        try {
              numRows = jdbcTemplateObject.update("update XBBNHD2ROOMS set CAPACITY=? where  ROOMS= ? ",
                            new Object[] {rooms.getCapacity(),rooms.getRooms() },
                            new int[] { Types.INTEGER,Types.VARCHAR });
        } catch (Throwable error) {
              System.out.println("Got error.  Returning null (404)");
              error.printStackTrace();
        } 
              
                     return rooms;

	}
		
	}
	


