package com.getroom;

import io.swagger.annotations.ApiModelProperty;

public class RoomBean {
	String empId,aimNo,rooms;
	int capacity;
	
	@ApiModelProperty(position = 1, required = true , value = "fetches the names of all the available rooms")
	public String getRooms() {
		return rooms;
	}
	@ApiModelProperty(position = 2, required = false , value = "empId contains 5 characters, that is unique to every employee")
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	@ApiModelProperty(position = 3, required = true , value = "Aim number specifies the location with the floor number and building")
	
	public String getAimNo() {
		return aimNo;
	}
	public void setAimNo(String aimNo) {
		this.aimNo = aimNo;
	}
	public void setRooms(String rooms) {
		this.rooms = rooms;
	}
	@ApiModelProperty(position = 4, required = true , value = "fetches the capacity of the available rooms")
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

}
