package com.getroom;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RoomMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int num) throws SQLException {
		// TODO Auto-generated method stub
		RoomBean rb=new RoomBean();
		rb.setEmpId(rs.getString("EMP_ID"));
		rb.setAimNo(rs.getString("AIM_NO"));
		rb.setRooms(rs.getString("ROOMS"));
		rb.setCapacity(rs.getInt("CAPACITY"));
		return rb;
	}

}
