package com.getroom;



import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;








import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


@EnableSwagger2
@Api(value = "/Availability", description = "Capacity and availability of rooms")
@RestController
public class RoomController {
	@Autowired
	RoomJDBC rjdbc;
	@Autowired
	MetaData metaData;
	@Autowired
	Data data;
	@Autowired
	ErrorDetails errorDetails;
	Response response=new Response();


//@ApiOperation(value="Fetches all available rooms")
@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Successful retrieval of user detail", response=RoomBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
	    @ApiResponse(code = 500, message = "Room unavailable"),
	    @ApiResponse(code = 400, message = "Internal server error")
	   }
	    
	)
@ApiOperation(value = "Retrieves the details of all rooms created", notes = "More notes about this method", response = Response.class)  

@RequestMapping(value="/rooms", method=RequestMethod.GET,  produces={MediaType.APPLICATION_JSON_VALUE} )
public ResponseEntity<Response> getRoom()
{
	 try {
		 List<RoomBean> rb=new ArrayList<RoomBean>();
		 rb=rjdbc.getRooms();
			saveMetaData(true,"Room details loaded","12345");
			saveData(null, rb);
			saveResponse(data,metaData, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			errorDetails.setCode("00005");
			errorDetails.setDescription(e.getMessage());;
			saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,errorDetails);
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
			//return response;
		}
return new ResponseEntity<Response>(response, HttpStatus.OK);


}


@ApiOperation(value="Fetches all available rooms in particular location" , notes = "More notes about this method", response = Response.class)
@ApiResponses(value = {
	    @ApiResponse(code = 200, message = "Successful retrieval of user detail", response=RoomBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
	    @ApiResponse(code = 500, message = "Room unavailable"),
	    @ApiResponse(code = 400, message = "Internal server error")
	   }
	    
	)
@RequestMapping(value="/particulars/{aimNo}", method=RequestMethod.GET, produces={MediaType.APPLICATION_JSON_VALUE})
public List<RoomBean> getRooms(@ApiParam(name = "aimNo", value = "Lists the available rooms in that particular location ", required = true) @PathVariable("aimNo") String aimNo  )
{
	List<RoomBean> rb=new ArrayList<RoomBean>();
	rb=rjdbc.getRooms(aimNo);
	return rb;
}


@ApiOperation(value="Adds available rooms", notes = "More notes about this method", response = Response.class)
@ApiResponses(value = {
	    @ApiResponse(code = 201, message = "Successful retrieval of user query", response=RoomBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
	    @ApiResponse(code = 500, message = "Room unavailable"),
	    @ApiResponse(code = 400, message = "Internal server error")
	   }
	    
	)
@ResponseStatus(value = HttpStatus.CREATED)

@RequestMapping(value="/adds", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE} )
public Response InsertRoomsDetails(@RequestBody RoomBean rb) {
	{
		
		List<RoomBean> rb1 = new ArrayList<RoomBean>();
		
		try{
			
			if(rb.getEmpId().length()>1 && rb.getEmpId().length()==5)
			{
						rjdbc.insert(rb);
				saveMetaData(true,"Room added","14563");
			saveData(null, rb1);
			saveResponse(data,metaData, null);
			}
			else
			{
				errorDetails.setCode("00007");
				errorDetails.setDescription("Employee id should be of 1-5 characters only");
				saveMetaData(false,"Error Occured","14563");
				saveResponse(null,metaData, errorDetails);
			}
		}
		catch(Exception e){
			e.printStackTrace();			
			errorDetails.setCode("00005");
			errorDetails.setDescription("Unique constraint violated");
			
			saveMetaData(false,"Error Occured","14563");
			//saveData(errorDetails, null);
			saveResponse(null,metaData, errorDetails);
			return response;
		}
}
	return response;
}
@ResponseStatus(value = HttpStatus.CREATED)

@RequestMapping(value="/removes/{rooms}", method=RequestMethod.DELETE, produces={MediaType.APPLICATION_JSON_VALUE} )
@ApiOperation(value="Deletes occupied rooms", notes = "More notes about this method", response = Response.class)
@ApiResponses(value = {
	   //@ApiResponse(code = 200, message = "Successful retrieval of user detail", response=RoomBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
	    @ApiResponse(code = 500, message = "Room unavailable"),
	    @ApiResponse(code = 404, message = "Response Not Found"),
	    @ApiResponse(code = 400, message = "Internal server error")
	   }
	    
	)


public Response deleteRoom(@ApiParam(name = "rooms", value = "Deletes the available rooms that are occupied now ", required = true) @PathVariable("rooms") String rooms  )
{
	List<RoomBean> testList = new ArrayList<RoomBean>();
	try{
		RoomBean rb=rjdbc.deleteRooms(rooms);			
		testList.add(rb);			
		saveMetaData(true,"Rooms Deleted","24541");
		saveData(null, testList);
		saveResponse(data,metaData, null);
		
	}
	catch(Exception e){
		e.printStackTrace();			
		errorDetails.setCode("00005");
		errorDetails.setDescription(e.getMessage());;
		saveMetaData(false,"Error Occured","24541");
		saveData(errorDetails, null);
		saveResponse(null,metaData,errorDetails);
		return response;
	}	
	return response;
}



/*public void testMethod1(@RequestBody RoomBean rb)
{
rjdbc.insert(rb);	
	System.out.println("Inserted Successfully!");
}*/
@ResponseStatus(value = HttpStatus.CREATED)
@ApiParam(name = "roomObj", value = "room object", required = true)
@RequestMapping(value="/modifies",method=RequestMethod.PUT, consumes=MediaType.APPLICATION_JSON_VALUE, produces={ MediaType.APPLICATION_JSON_VALUE})
@ApiOperation(value = "Updates the available room's capacity", notes = "More notes about this method", response = Response.class)
@ApiResponses(value = {
          @ApiResponse(code = 200, message = "Successful creation  of room ", response = Response.class),
           @ApiResponse(code = 404, message = "some thing went wrong",response = Response.class),
           @ApiResponse(code = 400, message = "room with id does not exist",response = Response.class),
           @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
       )
public Response updateTest(@RequestBody RoomBean roomObj)
{
       
       List<RoomBean> rb = new ArrayList<RoomBean>();
       try{
              roomObj =rjdbc.updateRooms(roomObj);                    
              rb.add(roomObj);                  
              saveMetaData(true,"Room Updated","123457");
              saveData(null, rb);
              saveResponse(data,metaData,null);
              
       }
       catch(Exception e){
              e.printStackTrace();              
              errorDetails.setCode("00005");
              errorDetails.setDescription(e.getMessage());;
              saveMetaData(false,"Error Occured","123457");
              //saveData(errorDetails, null);
              saveResponse(null,metaData, errorDetails);
              return response;
       }      
       return response;
}
private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
	response.setData(data);
	response.setMetaData(metaData);
	response.setError(errorDet);
}
private void saveData(ErrorDetails erroDet, List rb) {
	response.setError(erroDet);
		data.setOutput(rb);
	
}
private void saveMetaData(boolean success, String description, String responseId){
	
	
	metaData.setSuccess(success);
	metaData.setDescription(description);
	metaData.setResponseId(responseId);
}
	
@ExceptionHandler(TypeMismatchException.class)

public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {

    metaData.setDescription(null);

       metaData.setSuccess(false);

       response.setData(null);

    errorDetails.setCode("400");

       errorDetails.setDescription("Type mismatch exception occured");

    response.setError(errorDetails);

    ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

                 response, HttpStatus.BAD_REQUEST);

       return responseEntity;

}

@ExceptionHandler(Exception.class)

public @ResponseBody ResponseEntity<Object> generalExceptionHandler(

              Exception exception, HttpServletRequest request) {

      

       errorDetails.setCode("400");

       errorDetails.setDescription("Bad Request");

       ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

                 response, HttpStatus.BAD_REQUEST);

       return responseEntity;

}




}
