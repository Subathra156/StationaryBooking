/**
 * 
 */ app.controller("HttpGetController",['$cookieStore','$scope','placeorder', function ($cookieStore,$scope,placeorder) {
        	 $scope.employeeid=$cookieStore.get("empIdSession");
        	 $scope.items = [
        	        	        {item : "Pen"},
        	        	        {item : "Notepad"},
        	        	        {item : "Carbon Paper"},
        	        	        {item : "Carbon Paper"},
        	        	        {item : "Fevistick"},
        	        	        {item : "Stapler Pin"},
        	        	        {item : "Cellotape"},
        	        	        {item : "Paper Clip"},
        	        	        {item : "Paper weight"}
        	        	      
        	        	        
        	        	    ];
       
         $scope.orderItem = function(employeeid,deskNo,aimNo,orderItems,Quantity) {
        		 var id=$scope.employeeid;
                   var userDetail = {
         			employeeId:employeeid,
                                 deskNumber:deskNo,
                                 aimNumber:aimNo,
                                 item:orderItems,
                                 status:"Waiting",
                                 quantity:Quantity	
                             	
                                 };  
                   
                    
                   alert(id);
                  
                   placeorder.orderDetails(userDetail).then(function(response) {
                         console.log(response.statusText);
                         alert("Record inserted!!");

                    }, function errorCallback(response) {
                         console.log(response.statusText);
                         alert("Error!!!");
                         alert(response.statusText);
                    });
              };
         }]); 
        
     