/**
 * 
 */ 
app.controller("HttpDeleteController", function ($scope,userdelete,$cookieStore) {
	 $scope.empId = $cookieStore.get("empIdSession");
	 alert($scope.empId);
	 var employeeId=$scope.empId;
	// console.log($scope.empId);
        userdelete.fetchDetails(employeeId).then(function (response) {
             $scope.myData = response.data;
//console.log($scope.myData.employeeId);
         });
$scope.cancelOrder = function(employeeid,Item) {

    var userDetail = {
		employeeId:employeeid,
                   item:Item
                  }; 
     userdelete.deleteOrderDetails(userDetail).then(function(response) {
          console.log(response.statusText);
          alert("Order Cancelled!!");

     }, function errorCallback(response) {
          console.log(response.statusText);
          alert("Error!!!");
          alert(response.statusText);
     });
};
});