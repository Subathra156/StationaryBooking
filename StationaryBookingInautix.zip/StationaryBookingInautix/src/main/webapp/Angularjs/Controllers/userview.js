/**
 * 
 */ 
app.controller("ordersCtrl", function ($scope,view,$cookieStore) {
	 $scope.empId = $cookieStore.get("empIdSession");
	 var employeeId=$scope.empId;
	 alert($scope.empId);
	// console.log($scope.empId);
        
         view.fetchDetails(employeeId).then(function (response) {
             $scope.myData = response.data;
//console.log($scope.myData.employeeId);
        
         });
        	  $scope.mailFunction = function(empid,aimNumber,deskNumber,item,quantity,date) {
        	  	window.location.href="mailto:prvenkatesan@inautix.co.in?Subject=Stationary%20Order&body=Employee Id:"+empid+" %0D%0A	AIM Number:"+aimNumber+"%0D%0A	Desk Number:"+deskNumber+"%0D%0A	Item:"+item+"%0D%0A	Quantity:"+quantity+"%0D%0A	Date:"+date;
        	  	/*+empid+ " " +aimNumber+ " " +deskNumber+ " " +Item+ " " +quantity+ " " +date*/
        	  }

        	 });
        	