/**
 * 
 */app.controller("HttpGetController", function ($scope,signup) {

$scope.addEmployee = function(employeeid,commitid,pswd) {

          var userDetail = {
        		   employeeeId:employeeid,
        		   commitId: commitid,
        		   password: pswd
        		   }; 
          signup.fetchDetails(userDetail).then(function(response) {
                console.log(response.statusText);
                alert("Record inserted!!");

           }, function errorCallback(response) {
                console.log(response.statusText);
                alert("Error!!!");
                alert(response.statusText);
           });
     };
});
