/**
 * 
 */   
app.controller("HttpUpdateController", function ($scope,update,$cookieStore) {
	 $scope.empId = $cookieStore.get("empIdSession");
	 alert($scope.empId);
	 var employeeId=$scope.empId;
	// console.log($scope.empId);
        update.fetchDetails(employeeId).then(function (response) {
             $scope.myData = response.data;
//console.log($scope.myData.employeeId);
         });

        	$scope.modifyOrder = function(employeeid,Item,Quantity) {

        	    var userDetail = {
        			employeeId:employeeid,
        	                  item:Item,
        	                  quantity:Quantity	
        	              	
        	                  }; 
        	   update.updateOrderDetails(userDetail).then(function(response) {
        	          console.log(response.statusText);
        	          alert("Order updated!!");

        	     }, function errorCallback(response) {
        	          console.log(response.statusText);
        	          alert("Error!!!");
        	          alert(response.statusText);
        	     });
        	};


        	});
