app.controller("HttpGetController", function ($cookieStore,$scope,login,$window) {
	if($cookieStore.get('empIdSession')==undefined)
    {
   
       alert('In cookie session');
       $scope.session=true;
    
    
    }


$scope.checkdetail = function($location) {
	var detail=$scope.employee.userid;
	var pswd=$scope.employee.pswd;
	//console.log($scope.employee);
          var temp = angular.toJson($scope.employee);
       //   console.log(temp);
          /* $http({
                method : 'GET',
                url : 'http://localhost:8080/StationaryBookingSystemComplete/credentials/'+$scope.employee.userid+'/'+$scope.employee.pswd,
                data : temp,
             headers : {
                     'Content-Type' : 'application/json'
                } 
           })*/login.fetchDetails(detail,pswd,temp).then(function successCallback(response) {
                console.log(response);
                
                
                $cookieStore.put('empIdSession',detail);
               var value = $cookieStore.get("empIdSession");
                alert(value);
               $window.location.href="http://localhost:8080/StationaryBookingSystemComplete/Html/Copy%20of%20User%20Page.html";
               
              
               $scope.session=false;

           }, function errorCallback(response) {
        	   $scope.session=true;
               
               $cookieStore.remove('empIdSession');
               

                console.log(response);
               // alert("Error!!!Invalid Data");
                alert(response.statusText);
           });
     };
     

     $scope.logout=function(){
            
            
            $scope.session=true;
            
            $cookieStore.remove('empIdSession');
            
            
     }
     


});
