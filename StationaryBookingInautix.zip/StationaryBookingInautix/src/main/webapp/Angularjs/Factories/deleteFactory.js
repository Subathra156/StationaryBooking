/**
 * 
 */
app.factory("userdelete",['$http',function($http){
return{
        fetchDetails:function(employeeId) {
              
        return $http.get("http://localhost:8080/StationaryBookingSystemComplete/orders/"+employeeId);



    } ,    

    deleteOrderDetails:function(userDetail) {
       
    	return	$http({
            method : 'DELETE',
            url : 'http://localhost:8080/StationaryBookingSystemComplete/bookings',
            data : userDetail,
         headers : {
                 'Content-Type' : 'application/json'
            } 
       });

}     



}
}]);
