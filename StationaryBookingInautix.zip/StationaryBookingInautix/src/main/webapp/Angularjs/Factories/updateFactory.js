/**
 * 
 */

app.factory("update",['$http',function($http){
return{
        fetchDetails:function(employeeId) {
              
        return $http.get("http://localhost:8080/StationaryBookingSystemComplete/orders/"+employeeId);


    } ,    

   updateOrderDetails:function(userDetail) {
       
       return  $http({
	          method : 'PUT',
	          url : 'http://localhost:8080/StationaryBookingSystemComplete/bookings',
	          data : userDetail,
	       headers : {
	               'Content-Type' : 'application/json'
	          } 
	     });

}     



}
}]);
