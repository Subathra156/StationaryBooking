/**
 * 
 */
app.factory("placeorder",['$http',function($http){
return{
	
    orderDetails:function(userDetail) {
       
       return  $http({
           method : 'POST',
           url : 'http://localhost:8080/StationaryBookingSystemComplete/bookings',
           data : userDetail,
        headers : {
                'Content-Type' : 'application/json'
           } 
      });

}     



}
}]);
