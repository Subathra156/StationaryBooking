/**
 * 
 */

app.factory("view",['$http',function($http){
return{
        fetchDetails:function(employeeId) {
              
        return  $http.get("http://localhost:8080/StationaryBookingSystemComplete/orders/"+employeeId);


    }    

 

}
}]);
