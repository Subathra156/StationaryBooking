/**
 * 
 */
app.factory("signup",['$http',function($http){
return{
        fetchDetails:function(userDetail) {
              
        return   $http({
            method : 'POST',
            url : 'http://localhost:8080/StationaryBookingSystemComplete/credentials',
            data : userDetail,
         headers : {
                 'Content-Type' : 'application/json'
            } 
       });



    }


}
}]);


