/**
 * 
 */
app.factory("login",['$http',function($http){
return{
        fetchDetails:function(detail,pswd,temp) {
              
        return  $http({
            method : 'GET',
            url : 'http://localhost:8080/StationaryBookingSystemComplete/credentials/'+detail+'/'+pswd,
            data : temp,
         headers : {
                 'Content-Type' : 'application/json'
            } 
       });



    }


}
}]);


