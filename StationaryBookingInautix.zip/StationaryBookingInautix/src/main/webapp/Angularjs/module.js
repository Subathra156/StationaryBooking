/**
 * 
 */var app = angular.module("myApp", ['ngCookies','ngRoute']);
 app.config(function($routeProvider) {
     $routeProvider
     .when("/",{
    	 templateUrl : "NewFile.html"
             
     })
     .when("/UserPage", {
         templateUrl : "UserPage.html"
         
     })
     
     .when("/Delete", {
         templateUrl : "Delete.html",
         controller: 'HttpDeleteController'
     })
     .when("/Update", {
   	  
   	  
         templateUrl : "Update.html",
       	  controller: "HttpUpdateController"
     }).when("/Submit", {
         templateUrl : "PopulateBody.html",
       	  controller: "ordersCtrl"
       	 
     }).when("/PlaceOrder", {
         templateUrl : "PlaceOrder.html",
   	  controller: "HttpGetController"
   	 
 })
    
 });