
package com.bny.userbean;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class UserBean {
	String employeeId,deskNumber,aimNumber,item,status;
	String bookingDate,time;
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	@ApiModelProperty(position = 1, required = true , value = "Fetches the date and time of order")

	public String getDate() {
		return bookingDate;
	}
	public void setDate(String string) {
		this.bookingDate = string;
	}
	
	
	@ApiModelProperty(position = 2, required = true , value = "Fetches the status of booked order")

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	int quantity;
	@ApiModelProperty(position = 3, required = true , value = "Fetches the id of employee")

	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	
	@ApiModelProperty(position = 4, required = true , value = "Fetches the desk number of employee")

	public String getDeskNumber() {
		return deskNumber;
	}
	public void setDeskNumber(String deskNumber) {
		this.deskNumber = deskNumber;
	}
	
	@ApiModelProperty(position = 5, required = true , value = "Fetches the AIM number of employee")

	public String getAimNumber() {
		return aimNumber;
	}
	public void setAimNumber(String aimNumber) {
		this.aimNumber = aimNumber;
	}
	
	@ApiModelProperty(position = 5, required = true , value = "Gets the order from employee")

	public String getItem() {
		return item;
	}
	public void setItem(String item) {
		this.item = item;
	}
	
	@ApiModelProperty(position = 6, required = true , value = "Gets the quantity of the ordered item")

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

}
