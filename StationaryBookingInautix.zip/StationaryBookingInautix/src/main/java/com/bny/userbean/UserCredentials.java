package com.bny.userbean;

public class UserCredentials {

	String employeeeId,commitId,password;

	public String getEmployeeeId() {
		return employeeeId;
	}

	public void setEmployeeeId(String employeeeId) {
		this.employeeeId = employeeeId;
	}

	public String getCommitId() {
		return commitId;
	}

	public void setCommitId(String commitId) {
		this.commitId = commitId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
