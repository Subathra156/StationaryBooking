package com.bny.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;

import com.bny.userbean.UserCredentials;
import com.bny.userdao.LoginDao;



public class LoginJdbc implements LoginDao {
	
	private DataSource dataSource;
	   private JdbcTemplate jdbcTemplateObject;
	   List<UserCredentials> userList=new ArrayList<UserCredentials>();  
	   UserCredentials user=new UserCredentials();

	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);

}
	public UserCredentials insertStationaryDetails(UserCredentials userbean) {
		// TODO Auto-generated method stub
		int numRows = 0;
		String comid=userbean.getCommitId().toLowerCase();
		int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
		Object param[] = {comid,userbean.getEmployeeeId(),userbean.getPassword()};
		numRows= jdbcTemplateObject.update("insert into USER_CREDENTIALS values(?,?,?)", param, types);
		
		return userbean;
	}
	public UserCredentials updateStationaryDetails(UserCredentials userbean) {
		// TODO Auto-generated method stub
		int numRows = 0;
		int[] types = { Types.VARCHAR,Types.VARCHAR};
		
		Object param[] = {userbean.getPassword(),userbean.getCommitId()};
		//UserCredentials userdetails=null;
				
		numRows= jdbcTemplateObject.update("update USER_CREDENTIALS set password=? where commitId=?", param, types);
		return userbean;
	}
	
	
	
	public int getLoginDetails(String userid, String password) {
		// TODO Auto-generated method stub
	//	String comid=commitid.toLowerCase();
		String SQL = "select PASSWORD from USER_CREDENTIALS where EMPID= ?";
		int n=0;
	System.out.println(password);
	     // Student student = jdbcTemplateObject.query
	String     pswd= jdbcTemplateObject.queryForObject(SQL, new Object[]{userid}, String.class);
	System.out.println(pswd+password);
	     try
	     {
	    	if(pswd.equals(password)) 
	    		n=1;
	     }
	     catch(Exception e)
	     {
	    	n=-1; 
	     }

		return n;
	}
	
	
	////
	

	
}
