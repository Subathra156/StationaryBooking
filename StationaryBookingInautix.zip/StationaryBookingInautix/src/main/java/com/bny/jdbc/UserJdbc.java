package com.bny.jdbc;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.bny.userbean.UserBean;
import com.bny.userdao.UserDao;
import com.bny.usermapper.UserMapper;

public class UserJdbc implements UserDao{
	
List<UserBean> userList=new ArrayList<UserBean>();

private DataSource dataSource;
private JdbcTemplate jdbcTemplateObject;
 public void setDataSource(DataSource dataSource) {
   this.dataSource = dataSource;
   this.jdbcTemplateObject = new JdbcTemplate(dataSource);
}

	
	public List<UserBean> getBookedItems(String employeeId) {
		// TODO Auto-generated method 
		UserBean userbean=null;
			String SQL = "select * from STATIONARY_ADMIN where empId=?";
			//userbean.setStatus("Pending");
		    userList = jdbcTemplateObject.query(SQL, new Object[]{employeeId}, new UserMapper());
			
		return userList;
	}


	public List<UserBean> bookItems(UserBean userbean) {
		// TODO Auto-generated method stub
		 Date date=new Date();
		String s=date.toString();

	      int l=s.length();

	String q=s.substring(24,28);

	String dateFormat=s.substring(0,10)+" "+q;
	String time=s.substring(11, 20);
        userbean.setDate(dateFormat);
        userbean.setTime(time);
		int numRows = 0;
		int[] types = { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,Types.VARCHAR,Types.INTEGER,Types.VARCHAR,Types.VARCHAR,Types.VARCHAR};
		String status="Pending";
		userbean.setStatus("Pending");
	   
	    
		userList.add(userbean);
		Object param[] = {userbean.getEmployeeId(),userbean.getDeskNumber(),userbean.getAimNumber(),userbean.getItem(),userbean.getQuantity(),userbean.getDate(),userbean.getTime(),userbean.getStatus()};
		numRows= jdbcTemplateObject.update("insert into STATIONARY_ADMIN values(?,?,?,?,?,?,?,?)",param,types);
		return(numRows == 1 ? userList : null);

	}


	public List<UserBean> modifyQuantity(UserBean userbean) {
		// TODO Auto-generated method stub
		int numRows = jdbcTemplateObject.update("update STATIONARY_ADMIN set QTY=? where  ITEM= ? and empId=? ",
                 new Object[] {userbean.getQuantity(),userbean.getItem(),userbean.getEmployeeId() },
                 new int[] { Types.INTEGER,Types.VARCHAR, Types.VARCHAR });
		String SQL = "select * from STATIONARY_ADMIN ";
		//userbean.setStatus("Pending");
	    userList = jdbcTemplateObject.query(SQL, new Object[]{}, new UserMapper());
		
		return(numRows == 1 ? userList : null);
	}


	public UserBean deleteItem(UserBean userbean) {
		// TODO Auto-generated method stub
	UserBean usebean=null;
		usebean= jdbcTemplateObject.queryForObject("select * from STATIONARY_ADMIN  WHERE empId=? AND item=? ",new Object[] { userbean.getEmployeeId(),userbean.getItem() }, new UserMapper());
		int numRows = jdbcTemplateObject.update(
				"delete from STATIONARY_ADMIN WHERE empId=? AND item=?",
				new Object[] { userbean.getEmployeeId(),userbean.getItem() }, new int[] { Types.VARCHAR,Types.VARCHAR });

	
	return(numRows == 1 ? usebean : null);
	}


	public List<UserBean> getOrderedItems(String employeeId) {
		// TODO Auto-generated method 
		UserBean userbean=null;
			String SQL = "select * from STATIONARY_ADMIN where empId=?";
			//userbean.setStatus("Pending");
		    userList = jdbcTemplateObject.query(SQL, new Object[]{employeeId}, new UserMapper());
		    System.out.println("inside jdbc");
		    System.out.println(employeeId);
		return userList;
	}
	}


