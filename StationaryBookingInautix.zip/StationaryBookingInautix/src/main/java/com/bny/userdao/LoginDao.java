package com.bny.userdao;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.bny.userbean.UserCredentials;





public interface LoginDao {

	
	public UserCredentials insertStationaryDetails(UserCredentials userbean);
	
}
