package com.bny.userdao;

import java.util.List;

import com.bny.userbean.UserBean;

public interface UserDao {
	public List<UserBean> getBookedItems(String employeeId); 

}
