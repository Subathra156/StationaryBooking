package com.bny.usermapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bny.userbean.UserCredentials;


public class CredentialsMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserCredentials user=new UserCredentials();
		user.setCommitId(rs.getString("commitId"));
		user.setEmployeeeId(rs.getString("empId"));
		user.setPassword(rs.getString("password"));
		return user;
	}

}
