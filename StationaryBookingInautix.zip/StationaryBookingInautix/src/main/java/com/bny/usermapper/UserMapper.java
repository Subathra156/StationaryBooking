package com.bny.usermapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bny.userbean.UserBean;



public class UserMapper implements RowMapper  {

	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		UserBean userBean=new UserBean();
		userBean.setEmployeeId(rs.getString("EMPID"));
		userBean.setDeskNumber(rs.getString("DESKNUM"));
		userBean.setAimNumber(rs.getString("AIMNUM"));
		userBean.setItem(rs.getString("ITEM"));
		userBean.setQuantity(rs.getInt("QTY"));
		userBean.setStatus(rs.getString("STATUS"));
		userBean.setDate(rs.getString("BOOKINGDATE"));
		return userBean;
	}
	

}
