package com.bny.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.bny.jdbc.UserJdbc;
import com.bny.response.Data;
import com.bny.response.ErrorDetails;
import com.bny.response.MetaData;
import com.bny.response.Response;
import com.bny.userbean.UserBean;


@EnableSwagger2
@Api(value = "/Availability", description = "Booking Stationaries")
@RestController

public class UserController {
	
	
	
	
	@Autowired
	UserJdbc userJdbc;
	@Autowired
	MetaData metaData;
	@Autowired
	Data data;
	@Autowired
	ErrorDetails errorDetails;
	Response response=new Response();
	List<UserBean> userBean=new ArrayList<UserBean>();
	
	
	//To get all details
	@ApiOperation(value="Fetches all available orders for the particular employee" , notes = "More notes about this method", response = Response.class)
	@ApiParam(name = "userbean", value = "bean object", required = true)

	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Successful retrieval of order detail", response=UserBean.class ), 
			@ApiResponse(code = 404, message = "Resource not found"),
			@ApiResponse(code = 500, message = "Server error"),
		    @ApiResponse(code = 400, message = "Internal server error")
			
	})
	@ResponseStatus(value = HttpStatus.CREATED)

	@RequestMapping(value="/bookings/{employeeId}", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Response> GetBookedItems(@ApiParam(name = "employeeId", value = "Employee id that is unique to each employee", required = true)@PathVariable("employeeId") String employeeId)
	{
		try {
		List<UserBean> userBean=userJdbc.getBookedItems(employeeId);
		saveMetaData(true,"Order details loaded","12345");
		saveData(null, userBean);
		saveResponse(data,metaData, null);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		errorDetails.setCode("00005");
		errorDetails.setDescription(e.getMessage());;
		saveMetaData(false,"Error Occured","12345");
		
		saveResponse(null,metaData,errorDetails);
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
		//return response;
	}
return new ResponseEntity<Response>(response, HttpStatus.OK);


	}
	
	
	
	//To add order
	
	@ApiOperation(value="Places the stationary order", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		    @ApiResponse(code = 201, message = "Successful retrieval of user query", response=UserBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
		    @ApiResponse(code = 500, message = "server error"),
		    @ApiResponse(code = 400, message = "Internal server error")
		   }
		    
		)
	@ResponseStatus(value = HttpStatus.CREATED)

	@RequestMapping(value="/bookings", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	public Response bookItems(@RequestBody UserBean userbean)
	{

		try{
		
userBean=userJdbc.bookItems(userbean);
saveMetaData(true,"Order Placed","14563");

//saveData(null, rb2);
saveResponse(data,metaData, null);
System.out.println("Inside orderBooking");
}
	catch(Exception e){
		e.printStackTrace();			
		errorDetails.setCode("00005");
		
		saveMetaData(false,"Error Occured","14563");
		//saveData(errorDetails, null);
		errorDetails.setDescription("Order already exists-Unique constraint violated- ");
		saveResponse(null,metaData, errorDetails);
		return response;
	}

return response;
		
	}
	
	
	
	//To update order
	
	
	
	@ApiParam(name = "userbean", value = "bean object", required = true)
	@RequestMapping(value="/bookings", method=RequestMethod.PUT, produces={MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value = "Updates the quantity of the booked stationary", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
			 
	         @ApiResponse(code = 200, message = "Successful updation ", response = Response.class),
	           @ApiResponse(code = 404, message = "some thing went wrong",response = Response.class),
	           @ApiResponse(code = 400, message = "resource not found",response = Response.class),
	           @ApiResponse(code = 500, message = "Internal Server Error",response = Response.class)}
	       )
	public Response modifyQuanity(@RequestBody UserBean userbean)
	{
		List<UserBean> user = new ArrayList<UserBean>();
	
		 try{
	            
       userBean=userJdbc.modifyQuantity(userbean);
       user.add(userbean);                  
       saveMetaData(true,"Order Updated","123457");
       saveData(null, user);
       saveResponse(data,metaData,null);
		 }
       catch(Exception e){
           e.printStackTrace();              
           errorDetails.setCode("00005");
           errorDetails.setDescription(e.getMessage());;
           saveMetaData(false,"Error Occured","123457");
           //saveData(errorDetails, null);
           saveResponse(null,metaData, errorDetails);
           return response;
    }      
    return response;
		 }
	
	
	
	//To delete order
	
	@ResponseStatus(value = HttpStatus.CREATED)

	@RequestMapping(value="/bookings", method=RequestMethod.DELETE, consumes=MediaType.APPLICATION_JSON_VALUE, produces={MediaType.APPLICATION_JSON_VALUE})
	@ApiOperation(value="Deletes orders", notes = "More notes about this method", response = Response.class)
	@ApiResponses(value = {
		   //@ApiResponse(code = 200, message = "Successful retrieval of user detail", response=RoomBean.class ), @ApiResponse(code = 404, message = "User with given username does not exist"),
		    @ApiResponse(code = 500, message = "Order unavailable"),
		    @ApiResponse(code = 404, message = "Response Not Found"),
		    @ApiResponse(code = 400, message = "Internal server error")
		   }
		    
		)
	public Response deleteItem(@RequestBody UserBean userbean)
	{
		List<UserBean> user = new ArrayList<UserBean>();
		try{
			
		UserBean userBean=userJdbc.deleteItem(userbean);
		user.add(userbean);			
		saveMetaData(true,"Order Deleted","24541");
		saveData(null, user);
		saveResponse(data,metaData, null);
	}
		catch(Exception e){
			e.printStackTrace();			
			errorDetails.setCode("00005");
			errorDetails.setDescription("Order doesnt exist");
			saveMetaData(false,"Error Occured","24541");
			saveData(errorDetails, null);
			saveResponse(null,metaData,errorDetails);
			return response;
		}	
		return response;
	}
	
	///
	
	
	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List rb) {
		response.setError(erroDet);
			data.setOutput(rb);
		
	}
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	@ExceptionHandler(TypeMismatchException.class)

	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {

	    metaData.setDescription(null);

	       metaData.setSuccess(false);

	       response.setData(null);

	    errorDetails.setCode("400");

	       errorDetails.setDescription("Type mismatch exception occured");

	    response.setError(errorDetails);

	    ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	                 response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}

	@ExceptionHandler(Exception.class)

	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(

	              Exception exception, HttpServletRequest request) {

	      

	       errorDetails.setCode("400");

	       errorDetails.setDescription("Bad Request");

	       ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	                 response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}
	@RequestMapping(value="/orders/{employeeId}", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public List<UserBean> GetOrderedItems(@PathVariable String employeeId)
	{
		System.out.println("inside ctrlr");
		List<UserBean> userBean=userJdbc.getOrderedItems(employeeId);
		
		return userBean;
	}
	

	}
	
	
	


