package com.bny.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;






















import com.bny.jdbc.LoginJdbc;
import com.bny.response.Data;
import com.bny.response.ErrorDetails;
import com.bny.response.MetaData;
import com.bny.response.Response;
import com.bny.userbean.UserCredentials;




@RestController
public class CredentialsController {
	@Autowired
	LoginJdbc loginJdbc;
	@Autowired
	MetaData metaData;
	@Autowired
	Data data;
	
	@Autowired
	ErrorDetails errorDetails;
	Response response=new Response();
List<UserCredentials> userList=new ArrayList<UserCredentials>();
UserCredentials userbean=new UserCredentials();

@RequestMapping(value="/credentials/{userid}/{password}", method=RequestMethod.GET,consumes=MediaType.APPLICATION_JSON_VALUE)
public ResponseEntity<Response>  getDetails(@PathVariable("userid") String userid,@PathVariable("password") String password)
{ try {
	
	
	
	System.out.println("saesds");
	 List<UserCredentials> adminBean=new ArrayList<UserCredentials>();
	 int result=loginJdbc.getLoginDetails(userid,password);
	 System.out.println(result);
	 if(result == -1){
         throw new Exception();
}
else if(result == 0){
	 saveMetaData(true,"Invalid Password","88888");
		saveData(null, null);
		saveResponse(data,metaData, null);
		errorDetails.setDescription("Please enter correct password");;
		saveResponse(null,metaData,errorDetails);
		return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;

	
}
else
{
	
	return new ResponseEntity<Response>(response, HttpStatus.OK);
}
	 
}
	 catch (Exception e) {
	// TODO Auto-generated catch block
	errorDetails.setCode("00005");
	errorDetails.setDescription(e.getMessage());;
	saveMetaData(false,"Error Occured","12345");
	
	saveResponse(null,metaData,errorDetails);
	return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST) ;
	//return response;
}


}


	@RequestMapping(value="/credentials", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	public UserCredentials insertLoginDetails(@RequestBody UserCredentials usebean)
	
	{
		System.out.println("successfull");
		System.out.println(usebean.getCommitId());
		userbean=loginJdbc.insertStationaryDetails(usebean);
		//String s="Details inserted successfully";
		return userbean;
	
	}

	
	
	@RequestMapping(value="/credentials", method=RequestMethod.PUT,consumes=MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
public UserCredentials updateLoginDetails(@RequestBody UserCredentials usebean)
	
	{
		userbean=loginJdbc.updateStationaryDetails(usebean);
		
		return userbean;
	
	}
	
	
	///

	private void saveResponse(Data data, MetaData metaData, ErrorDetails errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(ErrorDetails erroDet, List rb) {
		response.setError(erroDet);
			data.setOutput(rb);
		
	}
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	
	@ExceptionHandler(TypeMismatchException.class)

	public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {

	    metaData.setDescription(null);

	       metaData.setSuccess(false);

	       response.setData(null);

	    errorDetails.setCode("400");

	       errorDetails.setDescription("Type mismatch exception occured");

	    response.setError(errorDetails);

	    ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	                 response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}

	@ExceptionHandler(Exception.class)

	public @ResponseBody ResponseEntity<Object> generalExceptionHandler(

	              Exception exception, HttpServletRequest request) {

	      

	       errorDetails.setCode("400");

	       errorDetails.setDescription("Bad Request");

	       ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(

	                 response, HttpStatus.BAD_REQUEST);

	       return responseEntity;

	}
	
	
		

}
