package com.bny.response;



import io.swagger.annotations.ApiModelProperty;

import java.util.List;



import com.bny.userbean.UserBean;
import com.bny.userbean.UserCredentials;




public class Data {
	@ApiModelProperty(position = 1, required = true, value = "This object contains details of stationary orders :output ")
	private List<UserBean> output;
	
	
	public List<UserBean>  getOutput() {
		return output;
	}
	public void setOutput(List<UserBean> outputList) {
		this.output = outputList;
	}
	
	private List<UserCredentials> Loginoutput;


	public List<UserCredentials> getLoginoutput() {
		return Loginoutput;
	}
	public void setLoginoutput(List<UserCredentials> loginoutput) {
		Loginoutput = loginoutput;
	}
	
	

}
