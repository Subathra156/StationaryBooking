package com.bny.response;



import io.swagger.annotations.ApiModelProperty;

public class ErrorDetails {
	@ApiModelProperty(position = 1, required = true, value = "Sets error codes for all possible errors :code ")
	private String code;
		@ApiModelProperty(position = 2, required = true, value = "Meaning of each error codes :description ")
	private String description;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
